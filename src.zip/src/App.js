import logo from './logo.svg';
import './App.css';
import Welcome from './App1';
import Welcome1 from './Welcome1';
import Employee from './Employee';
import App2 from './App2';
import App3 from './App3';
function App() {
  return (
    <div>
     
     
        {/* <Welcome fname="Ankita"/>
        <Welcome1 fname="Swati"/>
        <Welcome1 /> */}
     <Welcome1/>
     <hr/>
     <Employee/>
     <hr/>
     <App2/>
     <App3/>

    </div>
  );
}

export default App;
