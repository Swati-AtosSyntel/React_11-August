function Welcome(props){
    return(
        <h4>Hi {props.fname}, Welcome to React!!!!!</h4>
    )

}
export default Welcome;