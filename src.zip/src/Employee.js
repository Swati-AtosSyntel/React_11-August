import React,{Component} from 'react';

class Employee extends React.Component{
    constructor(){
        super();
        this.state={
            employees:[
                {id:123,name:"Swati"},
                {id:124,name:"Manisha"},
                {id:125,name:"Nisha"},
                {id:126,name:"Pradeep"},
                {id:127,name:"Jana"}
            ]
        }
    }
    render(){
        return(
            <div>
               {/*  <ul>
                    {this.state.employees.map((emp)=><li>{emp.name}</li>)}
                    </ul> */}
                    <table border="1">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                        </tr>
                        <tbody>
                            {this.state.employees.map((emp)=><Row employee={emp}/>)}
                        </tbody>
                    </table>
                
            </div>
        )
    }
}
class Row extends React.Component{
    render(){
        return(
            <tr>
                <td>
                    {this.props.employee.id}
                </td>
                <td>
                    {this.props.employee.name}
                </td>
            </tr>
        );
    }
}
export default Employee;