import React,{Component} from 'react';
import PropTypes from 'prop-types';
class App3 extends React.Component{
    render(){
        return(
            <div>
                <h1>React Props Validations</h1>
                <table>
                    <tr>
                        <th>Type</th>
                        <th>Value</th>
                        <th>Prop value defined(true/false)</th>
                    </tr>
                    <tr>
                    <td>
                        Array
                    </td>
                    <td>{this.props.arr}</td>
                    <td>
                        {this.props.arr ? "true" :"False"}
                    </td>
                    </tr>
                    <tr>
                    <td>
                        Function
                    </td>
                    <td>{this.props.propFunc}</td>
                    <td>
                        {this.props.propFunc ? "true" :"False"}
                    </td>
                    </tr>
                </table>
            </div>
        )
    }
}
App3.propTypes={
    arr:PropTypes.array.isRequired,
    propFunc:PropTypes.func
}
App3.defaultProps={
    arr:[23,45,56,678],
    //propFunc:function (x){return x*2}
}
export default App3;