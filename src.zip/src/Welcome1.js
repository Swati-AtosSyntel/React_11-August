import React,{Component} from 'react';
class Welcome1 extends React.Component{
    constructor(props){
        super(props);
        this.state={message:"React is opensource front end javascript library."}
        this.updateMessage=this.updateMessage.bind(this);
    }
    updateMessage(){
        this.setState({message:"React is used to build complex UI"})
    }
    render(){
        return (
            <div>
                <h1>Hi {this.props.fname}!!!!</h1>
                {/* <h3>{this.state.message}</h3>
                <button onClick={this.updateMessage}>Click Here</button> */}
                <Content msg={this.state.message} 
                updateStateProp={this.updateMessage}></Content>
        </div>
        );
    }
}
Welcome1.defaultProps={
    fname:"React!!!"
}
class Content extends React.Component{
    render(){
        return(
            <div>
                <button onClick={this.props.updateStateProp}>UpdateMessage</button>
                <h3>{this.props.msg}</h3>
            </div>
        )
    }
}
export default Welcome1;
