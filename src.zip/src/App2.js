import React,{Component} from 'react';
class App2 extends React.Component{
    constructor(){
        super();
        this.state={num:0}
        this.setNewNum=this.setNewNum.bind(this);
    }
    setNewNum(){
        this.setState({num:this.state.num+2})
    }
    render(){
        return(
            <div>
                <button onClick={this.setNewNum}>Increment Number</button>
                <Content1 newNum={this.state.num}/>
            </div>
        )
    }
}
class Content1 extends React.Component{
    componentWillMount()
    {
        console.log("Component will Mount")
    }
    componentDidMount()
    {
        console.log("Component Did Mount")
    }
    componentWillReceiveProps(newProps){
        console.log("Component received props")
    }
    shouldComponentUpdate(newProps,newState)
    {
        return false;
    }
    componentWillUpdate(nextProps,nextState)
    {
        console.log("Component Will Update")
    }
    render(){
        return(
            <div>
                <h4>{this.props.newNum}</h4>
            </div>
        )
    }
}
export default App2;