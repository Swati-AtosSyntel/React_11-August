function UserLogin(props){
    return <h1>Welcome User!!</h1>
}
function GuestLogin(props){
    return <h1>Welcome Guest User....Please signup here</h1>
}

function SignUp(props){
    const isLoggedIn=props.isLoggedIn;
    if(isLoggedIn){
        return <UserLogin/>

    }
    return <GuestLogin/>;
}
export default SignUp;